# Maintainer Nishant Singh

import requests
import json
import pprint
import datetime
import time


def get_channel_users(user_id):
    payload_user = {'token': 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', 'user': user_id}
    user_det = requests.post('https://slack.com/api/users.info', data=payload_user)
    json_user_loader = json.loads(user_det.text)

    return (json_user_loader['user']['name'])

def post_messages_to_slack():
    uploadfile = "/tmp/handoff_text"  # Please input the filename with path that you want to upload.
    with open(uploadfile, 'rb') as f:
        param = {
               'token': 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
               'channels': 'G08G8EVRT',
               'title': 'Handoff'
                }
        r = requests.post(
                "https://slack.com/api/files.upload",
                params=param,
                files={'file': f}
               )
        print r.text
        print r.headers
        print r.status_code


def get_channel_messages():
    start_time_messages = datetime.datetime.today().replace(hour=10, minute=30, second=0, microsecond=0) ## 4:00:00 PM GST    
    ##TEST##start_time_messages =  datetime.datetime.today().replace(hour=5, minute=30, second=0, microsecond=0)
    epooch_oldest = time.mktime(start_time_messages.timetuple())
    stop_time_messages = datetime.datetime.today().replace(hour=11, minute=30, second=0, microsecond=0)  ## 5:00:00 PM
    ##TEST##stop_time_messages = datetime.datetime.today().replace(hour=6, minute=30, second=0, microsecond=0)
    epooch_newsest = time.mktime(stop_time_messages.timetuple())

    payload = {'token': 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', 'channel': 'G6G2W5L07', 'latest':epooch_newsest  , 'oldest':epooch_oldest }
    r = requests.post('https://slack.com/api/groups.history', data=payload)

    print "========="
    json_objects = json.loads(r.text)
    file = open("/tmp/handoff_text","w")
    for i in json_objects['messages']:
          user_id = i['user']
          return_names = get_channel_users(user_id)
          print return_names
          file.write(return_names+":"+"\n")
          print i['text']
          file.write(""+i['text']+"\n\n")


def handler(event, context):
    get_channel_messages()
    post_messages_to_slack()
